# your_app_name/__init__.py
default_app_config = 'myapp.apps.MyappConfig'
